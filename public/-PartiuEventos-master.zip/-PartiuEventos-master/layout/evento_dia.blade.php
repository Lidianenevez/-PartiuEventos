<div class="container wow fadeInUp">
  <div class="section-header">
    <h2>Eventos mais Recentes</h2>
  </div>

  <ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Hoje</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#day-2" role="tab" data-toggle="tab">Amanhã</a>
    </li>
  </ul>

  

  <div class="tab-content row justify-content-center">

    <!-- Schdule Day 1 -->
    <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">

      <div class="row schedule-item">
        <div class="col-md-2"><time>10:00 AM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/1.jpg" alt="Brenden Legros">
          </div>
          <h4>Keynote <span>Brenden Legros</span></h4>
          <p>Facere provident incidunt quos voluptas.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>11:00 AM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/2.jpg" alt="Hubert Hirthe">
          </div>
          <h4>Et voluptatem iusto dicta nobis. <span>Hubert Hirthe</span></h4>
          <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>12:00 AM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/3.jpg" alt="Cole Emmerich">
          </div>
          <h4>Explicabo et rerum quis et ut ea. <span>Cole Emmerich</span></h4>
          <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>02:00 PM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/4.jpg" alt="Jack Christiansen">
          </div>
          <h4>Qui non qui vel amet culpa sequi. <span>Jack Christiansen</span></h4>
          <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>03:00 PM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/5.jpg" alt="Alejandrin Littel">
          </div>
          <h4>Quos ratione neque expedita asperiores. <span>Alejandrin Littel</span></h4>
          <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>04:00 PM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/6.jpg" alt="Willow Trantow">
          </div>
          <h4>Quo qui praesentium nesciunt <span>Willow Trantow</span></h4>
          <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p>
        </div>
      </div>

    </div>
    <!-- End Schdule Day 1 -->

    <!-- Schdule Day 2 -->
    <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-2">

      <div class="row schedule-item">
        <div class="col-md-2"><time>10:00 AM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/1.jpg" alt="Brenden Legros">
          </div>
          <h4>Libero corrupti explicabo itaque. <span>Brenden Legros</span></h4>
          <p>Facere provident incidunt quos voluptas.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>11:00 AM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/2.jpg" alt="Hubert Hirthe">
          </div>
          <h4>Et voluptatem iusto dicta nobis. <span>Hubert Hirthe</span></h4>
          <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>12:00 AM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/3.jpg" alt="Cole Emmerich">
          </div>
          <h4>Explicabo et rerum quis et ut ea. <span>Cole Emmerich</span></h4>
          <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>02:00 PM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/4.jpg" alt="Jack Christiansen">
          </div>
          <h4>Qui non qui vel amet culpa sequi. <span>Jack Christiansen</span></h4>
          <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>03:00 PM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/5.jpg" alt="Alejandrin Littel">
          </div>
          <h4>Quos ratione neque expedita asperiores. <span>Alejandrin Littel</span></h4>
          <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p>
        </div>
      </div>

      <div class="row schedule-item">
        <div class="col-md-2"><time>04:00 PM</time></div>
        <div class="col-md-10">
          <div class="speaker">
            <img src="img/speakers/6.jpg" alt="Willow Trantow">
          </div>
          <h4>Quo qui praesentium nesciunt <span>Willow Trantow</span></h4>
          <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p>
        </div>
      </div>

    </div>
    <!-- End Schdule Day 2 -->

    

  </div>

</div>
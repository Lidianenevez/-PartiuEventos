<div id="logo" class="pull-left">
        <!-- Uncomment below if you prefer to use a text logo -->
        <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
        <a href="#intro" class="scrollto"><img src="img/logo.jpg" alt="" title=""></a>
      </div>

<nav id="nav-menu-container">
  <ul class="nav-menu">
    <li class="menu-active"><a href="index.blade.php">Home</a></li>
    <li><a href="eventos.blade.php">Eventos</a></li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Categorias
      </a>
      <div class="dropdown-menu" >
        <a class="dropdown-item" href="#">Show</a>
        <a class="dropdown-item" href="#">Palestras</a>
        <a class="dropdown-item" href="#">Workshops</a>
      </div>
    </li>
    <li><a class="linkmenu" data-toggle="modal" data-target="#cadastro">Cadastre-se</a></li>
    <li><a class="linkmenu" data-toggle="modal" data-target="#login">Login</a></li>
    <li><a href="novo-evento.blade.php" class="about-btn scrollto">Divulgar Evento</a></li>
  </ul>

</nav><!-- #nav-menu-container -->
</div>
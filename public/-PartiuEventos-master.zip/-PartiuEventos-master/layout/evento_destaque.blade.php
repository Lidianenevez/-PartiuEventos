<div class="container">
  <div class="section-header">
    <h2>Eventos em Destaque</h2>
  </div>

  <div class="row">
    <div class="col-lg-4 col-md-6">
      <div class="speaker">
        <img src="img/speakers/5.jpg" alt="Speaker 1" class="img-fluid">
        <div class="details">
          <center>
            <h3><a class="nomeevento" href="speaker-details.html">Hubert Hirthe</a></h3>
            <div class="social">
              <a href=""><i class="fa fa-map-marker" aria-hidden="true"></i></a>
              <a href=""><i class="fa fa-calendar" aria-hidden="true"></i>
              <a href=""><i class="fa fa-clock-o" aria-hidden="true"></i></a>
              <a href="" class="btn4">Saiba mais</a>
            </div>
          </center>
        </div>
    </div>
  </div>
    <div class="col-lg-4 col-md-6">
      <div class="speaker">
        <img src="img/speakers/2.jpg" alt="Speaker 2" class="img-fluid">
        <div class="details">
          <center>
            <h3><a class="nomeevento" href="speaker-details.html">Hubert Hirthe</a></h3>
            <div class="social">
              <a href=""><i class="fa fa-map-marker" aria-hidden="true"></i></a>
              <a href=""><i class="fa fa-calendar" aria-hidden="true"></i>
              <a href=""><i class="fa fa-clock-o" aria-hidden="true"></i></a>
              <a href="" class="btn4">Saiba mais</a>
            </div>
          </center>
        </div>
    </div>
  </div>
    <div class="col-lg-4 col-md-6">
      <div class="speaker">
        <img src="img/speakers/3.jpg" alt="Speaker 3" class="img-fluid">
       <div class="details">
          <center>
            <h3><a class="nomeevento" href="speaker-details.html">Hubert Hirthe</a></h3>
            <div class="social">
              <a href=""><i class="fa fa-map-marker" aria-hidden="true"></i></a>
              <a href=""><i class="fa fa-calendar" aria-hidden="true"></i>
              <a href=""><i class="fa fa-clock-o" aria-hidden="true"></i></a>
              <a href="" class="btn4">Saiba mais</a>
            </div>
          </center>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="speaker">
        <img src="img/speakers/4.jpg" alt="Speaker 4" class="img-fluid">
        <div class="details">
          <center>
            <h3><a class="nomeevento" href="speaker-details.html">Hubert Hirthe</a></h3>
            <div class="social">
              <a href=""><i class="fa fa-map-marker" aria-hidden="true"></i></a>
              <a href=""><i class="fa fa-calendar" aria-hidden="true"></i>
              <a href=""><i class="fa fa-clock-o" aria-hidden="true"></i></a>
              <a href="" class="btn4">Saiba mais</a>
            </div>
          </center>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="speaker">
        <img src="img/speakers/1.jpg" alt="Speaker 5" class="img-fluid">
        <div class="details">
          <center>
            <h3><a class="nomeevento" href="speaker-details.html">Hubert Hirthe</a></h3>
            <div class="social">
              <a href=""><i class="fa fa-map-marker" aria-hidden="true"></i></a>
              <a href=""><i class="fa fa-calendar" aria-hidden="true"></i>
              <a href=""><i class="fa fa-clock-o" aria-hidden="true"></i></a>
              <a href="" class="btn4">Saiba mais</a>
            </div>
          </center>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="speaker">
        <img src="img/speakers/6.jpg" alt="Speaker 6" class="img-fluid">
        <div class="details">
          <center>
            <h3><a class="nomeevento" href="speaker-details.html">Hubert Hirthe</a></h3>
            <div class="social">
              <a href=""><i class="fa fa-map-marker" aria-hidden="true"></i></a>
              <a href=""><i class="fa fa-calendar" aria-hidden="true"></i>
              <a href=""><i class="fa fa-clock-o" aria-hidden="true"></i></a>
              <a href="" class="btn4">Saiba mais</a>
            </div>
          </center>
        </div>
      </div>
    </div>
  </div>
</div>


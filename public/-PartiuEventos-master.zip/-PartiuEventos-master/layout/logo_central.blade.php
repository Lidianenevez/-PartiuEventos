<div class="intro-container wow fadeIn">
	 <!--<div class="social-links">
		<a href="#" class="twitter"><i class=" btn fa fa-twitter"></i></a>
		<a href="#" class="facebook"><i class="btn fa fa-facebook"></i></a>
		<a href="#" class="instagram"><i class="btn fa fa-instagram"></i></a>
		<a href="#" class="google-plus"><i class="btn fa fa-google-plus"></i></a>
	</div> -->

	<img src="img/logo.jpg" class="rounded-circle img-center img-fluid shadow shadow-lg--hover" style="width: 300px; ">

  <form>
    <div class="form-row">
     <div class="form-group col-md-5">
      <label class="labelbranca">Nome</label>
      <input type="text" class="form-control" placeholder="Pesquisar por nome" >
    </div>
    <div class="form-group col-md-5">
      <label for="inputCity" class="labelbranca">Cidade</label>
      <input type="text" class="form-control" id="inputCity" placeholder="Pesquisar por cidade" >
    </div>
    <div class="form-group col-md-2">
      <button class="btn btn3" type="submit" >Procurar <i class="fa fa-search" aria-hidden="true"></i></button>
    </div>
  </div>
  
</form>
</div>